function removesemester(val){
  
    number= Number(val)
  
    calculator_div= ".whole-calculator-"+number
    document.querySelector(calculator_div).remove()
   semesters--
   semesters_no--
   var val= (document.querySelector(".white-bg").clientHeight);

 }   