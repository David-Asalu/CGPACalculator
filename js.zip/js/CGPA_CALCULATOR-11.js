function save_selected(selected){
    var selected_cgpa = selected.options[selected.selectedIndex].text
   
   }