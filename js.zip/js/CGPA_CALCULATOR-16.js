function   redogpa(){
    for(y=0; y<semesters_no; y++){
        gpa_array(y)

    }
    document.querySelector(".cgpa-value").value = ""         
}
